import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeGrades = async (grades: number[]): Promise<string> => {
  if (grades.length === 0) return "Aucune donnée à analyser.";
  
  const sum = grades.reduce((a, b) => a + b, 0);
  const avg = sum / grades.length;
  const max = Math.max(...grades);
  const min = Math.min(...grades);

  const prompt = `En tant qu'assistant pédagogique expert, analyse cette série de points de barème (Total: ${sum}, Moyenne: ${avg.toFixed(2)}, Max: ${max}, Min: ${min}). 
  Liste des points: ${grades.join(', ')}. 
  Fournis une analyse synthétique en français incluant:
  1. Une observation sur la structure de la note.
  2. Des conseils sur ce que cela indique sur le travail de l'élève.
  Réponds au format texte court (Markdown).`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "L'analyse n'a pas pu être générée.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Erreur d'analyse IA.";
  }
};